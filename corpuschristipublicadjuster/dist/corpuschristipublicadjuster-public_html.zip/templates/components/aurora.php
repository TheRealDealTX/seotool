<div class="aurora" aria-hidden="true"><span></span><span></span><span></span></div>
